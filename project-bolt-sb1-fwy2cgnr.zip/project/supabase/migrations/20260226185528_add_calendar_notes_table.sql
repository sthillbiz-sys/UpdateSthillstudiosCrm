/*
  # Add Calendar Notes Table
  
  1. New Tables
    - `calendar_notes`
      - `id` (uuid, primary key)
      - `note_date` (date, the calendar date for this note)
      - `note_text` (text, the note content)
      - `contact_id` (uuid, optional reference to contacts)
      - `contact_name` (text, contact name for quick display)
      - `follow_up_type` (text, type: call_back, meeting, reminder, other)
      - `priority` (text, priority: low, medium, high)
      - `completed` (boolean, whether note is completed)
      - `created_by` (uuid, foreign key to auth.users)
      - `created_at` (timestamptz, default now())
      - `updated_at` (timestamptz, default now())
  
  2. Security
    - Enable RLS on calendar_notes table
    - Add policies for authenticated users to manage calendar notes
    - Users can see all team calendar notes for collaboration
*/

CREATE TABLE IF NOT EXISTS calendar_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_date date NOT NULL,
  note_text text NOT NULL,
  contact_id uuid DEFAULT NULL,
  contact_name text DEFAULT '',
  follow_up_type text NOT NULL DEFAULT 'reminder',
  priority text NOT NULL DEFAULT 'medium',
  completed boolean DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_calendar_notes_date ON calendar_notes(note_date);
CREATE INDEX IF NOT EXISTS idx_calendar_notes_created_by ON calendar_notes(created_by);

ALTER TABLE calendar_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all team calendar notes"
  ON calendar_notes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create calendar notes"
  ON calendar_notes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own calendar notes"
  ON calendar_notes FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can delete their own calendar notes"
  ON calendar_notes FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by);
