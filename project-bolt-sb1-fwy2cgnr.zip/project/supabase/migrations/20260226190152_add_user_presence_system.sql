/*
  # Add User Presence System
  
  1. New Tables
    - `user_presence`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `status` (text, status: available, busy, in_meeting, on_break, lunch, away, offline)
      - `custom_message` (text, optional custom status message)
      - `last_activity` (timestamptz, last activity timestamp)
      - `is_on_call` (boolean, whether user is currently on a call)
      - `updated_at` (timestamptz, default now())
      - `created_at` (timestamptz, default now())
  
  2. Security
    - Enable RLS on user_presence table
    - All authenticated users can view presence status
    - Users can only update their own presence
  
  3. Indexes
    - Index on user_id for fast lookups
    - Index on status for filtering
*/

CREATE TABLE IF NOT EXISTS user_presence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  status text NOT NULL DEFAULT 'offline',
  custom_message text DEFAULT '',
  last_activity timestamptz DEFAULT now(),
  is_on_call boolean DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_presence_user_id ON user_presence(user_id);
CREATE INDEX IF NOT EXISTS idx_user_presence_status ON user_presence(status);

ALTER TABLE user_presence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All users can view presence status"
  ON user_presence FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own presence"
  ON user_presence FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own presence"
  ON user_presence FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own presence"
  ON user_presence FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION update_presence_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_presence_timestamp
  BEFORE UPDATE ON user_presence
  FOR EACH ROW
  EXECUTE FUNCTION update_presence_timestamp();
