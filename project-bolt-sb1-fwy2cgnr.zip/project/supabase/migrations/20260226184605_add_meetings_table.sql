/*
  # Add Meetings Table

  1. New Tables
    - `meetings`
      - `id` (uuid, primary key)
      - `title` (text, meeting title)
      - `meeting_type` (text, type: video, phone, in-person)
      - `scheduled_date` (date, meeting date)
      - `scheduled_time` (time, meeting time)
      - `duration` (text, meeting duration)
      - `description` (text, meeting notes/agenda)
      - `room_name` (text, Jitsi room name)
      - `status` (text, scheduled/completed/cancelled)
      - `attendees` (text array, list of attendee emails)
      - `created_by` (uuid, foreign key to auth.users)
      - `created_at` (timestamptz, default now())
      - `updated_at` (timestamptz, default now())

  2. Security
    - Enable RLS on meetings table
    - Add policies for authenticated users to manage their meetings
*/

CREATE TABLE IF NOT EXISTS meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  meeting_type text NOT NULL DEFAULT 'video',
  scheduled_date date NOT NULL,
  scheduled_time time NOT NULL,
  duration text NOT NULL DEFAULT '30 minutes',
  description text DEFAULT '',
  room_name text NOT NULL,
  status text NOT NULL DEFAULT 'scheduled',
  attendees text[] DEFAULT '{}',
  created_by uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own meetings"
  ON meetings FOR SELECT
  TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Users can create meetings"
  ON meetings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own meetings"
  ON meetings FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can delete their own meetings"
  ON meetings FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by);
