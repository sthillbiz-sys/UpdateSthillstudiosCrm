/*
  # Link Calendar Notes to Contacts
  
  1. Changes
    - Add foreign key constraint from calendar_notes.contact_id to contacts.id
    - Add index for better query performance
  
  2. Security
    - No RLS changes needed (already configured)
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'calendar_notes_contact_id_fkey'
    AND table_name = 'calendar_notes'
  ) THEN
    ALTER TABLE calendar_notes
    ADD CONSTRAINT calendar_notes_contact_id_fkey
    FOREIGN KEY (contact_id)
    REFERENCES contacts(id)
    ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_calendar_notes_contact_id ON calendar_notes(contact_id);
