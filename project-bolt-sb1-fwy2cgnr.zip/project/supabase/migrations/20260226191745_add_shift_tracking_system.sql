/*
  # Shift Tracking System

  1. New Tables
    - `shift_entries`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `shift_date` (date) - Date of the shift
      - `clock_in` (timestamptz) - When employee clocks in
      - `clock_out` (timestamptz, nullable) - When employee clocks out
      - `lunch_start` (timestamptz, nullable) - When lunch break starts
      - `lunch_end` (timestamptz, nullable) - When lunch break ends
      - `lunch_duration_minutes` (integer) - Total lunch time in minutes
      - `total_hours` (numeric) - Calculated total hours worked (excluding lunch)
      - `status` (text) - Current status: 'clocked_in', 'on_lunch', 'clocked_out'
      - `notes` (text, nullable) - Optional notes for the shift
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `shift_entries` table
    - Add policies for users to manage their own shift entries
*/

CREATE TABLE IF NOT EXISTS shift_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  shift_date date NOT NULL DEFAULT CURRENT_DATE,
  clock_in timestamptz NOT NULL DEFAULT now(),
  clock_out timestamptz,
  lunch_start timestamptz,
  lunch_end timestamptz,
  lunch_duration_minutes integer DEFAULT 0,
  total_hours numeric(5,2),
  status text NOT NULL DEFAULT 'clocked_in',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE shift_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own shift entries"
  ON shift_entries
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own shift entries"
  ON shift_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own shift entries"
  ON shift_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own shift entries"
  ON shift_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_shift_entries_user_id'
  ) THEN
    CREATE INDEX idx_shift_entries_user_id ON shift_entries(user_id);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_shift_entries_shift_date'
  ) THEN
    CREATE INDEX idx_shift_entries_shift_date ON shift_entries(shift_date);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_shift_entries_status'
  ) THEN
    CREATE INDEX idx_shift_entries_status ON shift_entries(status);
  END IF;
END $$;