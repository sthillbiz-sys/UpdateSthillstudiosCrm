import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from './supabase';
import { useAuth } from './auth';

export type PresenceStatus = 'available' | 'busy' | 'in_meeting' | 'on_break' | 'lunch' | 'away' | 'offline';

interface UserPresence {
  user_id: string;
  status: PresenceStatus;
  custom_message: string;
  is_on_call: boolean;
  last_activity: string;
}

interface PresenceContextType {
  myPresence: UserPresence | null;
  teamPresence: UserPresence[];
  updatePresence: (status: PresenceStatus, customMessage?: string) => Promise<void>;
  setOnCall: (isOnCall: boolean) => Promise<void>;
}

const PresenceContext = createContext<PresenceContextType | undefined>(undefined);

export function PresenceProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [myPresence, setMyPresence] = useState<UserPresence | null>(null);
  const [teamPresence, setTeamPresence] = useState<UserPresence[]>([]);

  useEffect(() => {
    if (!user) return;

    initializePresence();
    loadTeamPresence();

    const presenceChannel = supabase
      .channel('presence-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_presence'
        },
        () => {
          loadTeamPresence();
        }
      )
      .subscribe();

    const activityInterval = setInterval(() => {
      updateLastActivity();
    }, 30000);

    window.addEventListener('beforeunload', () => {
      updatePresence('offline');
    });

    return () => {
      presenceChannel.unsubscribe();
      clearInterval(activityInterval);
    };
  }, [user]);

  const initializePresence = async () => {
    if (!user) return;

    try {
      const { data: existing } = await supabase
        .from('user_presence')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (existing) {
        const { data, error } = await supabase
          .from('user_presence')
          .update({
            status: 'available',
            last_activity: new Date().toISOString()
          })
          .eq('user_id', user.id)
          .select()
          .single();

        if (error) throw error;
        setMyPresence(data);
      } else {
        const { data, error } = await supabase
          .from('user_presence')
          .insert({
            user_id: user.id,
            status: 'available',
            last_activity: new Date().toISOString()
          })
          .select()
          .single();

        if (error) throw error;
        setMyPresence(data);
      }
    } catch (error) {
      console.error('Error initializing presence:', error);
    }
  };

  const loadTeamPresence = async () => {
    try {
      const { data, error } = await supabase
        .from('user_presence')
        .select('*')
        .order('status');

      if (error) throw error;
      setTeamPresence(data || []);
    } catch (error) {
      console.error('Error loading team presence:', error);
    }
  };

  const updatePresence = async (status: PresenceStatus, customMessage = '') => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_presence')
        .update({
          status,
          custom_message: customMessage,
          last_activity: new Date().toISOString()
        })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;
      setMyPresence(data);
    } catch (error) {
      console.error('Error updating presence:', error);
    }
  };

  const setOnCall = async (isOnCall: boolean) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_presence')
        .update({
          is_on_call: isOnCall,
          status: isOnCall ? 'busy' : 'available',
          last_activity: new Date().toISOString()
        })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;
      setMyPresence(data);
    } catch (error) {
      console.error('Error updating call status:', error);
    }
  };

  const updateLastActivity = async () => {
    if (!user) return;

    try {
      await supabase
        .from('user_presence')
        .update({
          last_activity: new Date().toISOString()
        })
        .eq('user_id', user.id);
    } catch (error) {
      console.error('Error updating last activity:', error);
    }
  };

  return (
    <PresenceContext.Provider value={{ myPresence, teamPresence, updatePresence, setOnCall }}>
      {children}
    </PresenceContext.Provider>
  );
}

export function usePresence() {
  const context = useContext(PresenceContext);
  if (context === undefined) {
    throw new Error('usePresence must be used within a PresenceProvider');
  }
  return context;
}
